1. ติดตั้งด้วย: npm install
2. เริ่มเซิร์ฟเวอร์: node server/server.js
3. เข้าหน้าเว็บที่ http://localhost:3000